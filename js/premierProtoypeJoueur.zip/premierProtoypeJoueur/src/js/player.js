window.onload = init;



class Player {
  
  constructor(ctx, height, width, vitesse) {
      this.height=height;
    this.width=width;
    this.ctx=ctx;
      this.x=(canvas.width-width)/2;
      this.y=canvas.height-height-20;
      this.vitesse=vitesse;
      
  }
    

  
  draw() {
  ctx.save();  
  ctx.fillStyle="black";
  ctx.fillRect(this.x, this.y, this.height, this.width);
  ctx.restore();  
  }
    moveLeft(ctx){
        
       if ((this.x-this.vitesse)>=0)
        this.x-=this.vitesse;        
        this.draw();
    }
    moveRight(ctx){
        
       if (this.x+this.vitesse<=canvas.width-this.width)
        this.x+=this.vitesse;        
        this.draw();
    }
    moveUp(ctx){
        
       if (this.y-this.vitesse>=0)
        this.y-=this.vitesse;        
        this.draw();
    }
    moveDown(ctx){
        
       if (this.y+this.vitesse<=canvas.height-this.height)
        this.y+=this.vitesse;        
        this.draw();
    }
  
  
  
}

class Bullet {
    constructor(player) {
        this.x = player.x+player.width/2-12;
        this.y = player.y-13;
        
    }

    draw() {
        ctx.save();
        ctx.translate(this.x, this.y);
        ctx.fillStyle="black";
        ctx.fillRect(0, 0, 12, 12);
        ctx.restore();
    }

  
    move() {
    
        ctx.clearRect(this.x, this.y, 12, 13);      
        this.y-=5;
        this.draw();
        if ((this.y-p.y-p.height)>canvas.height)
        clearInterval(t);
        
    }
    
}




function init() {
  canvas = document.querySelector("#myCanvas");
  ctx=canvas.getContext("2d");
 
  p=new Player(ctx, 40, 50, 10);
  p.draw();
  
}



        


window.onkeydown = function(e) {
    let key = e.keyCode || e.which;
    switch (key) {
        case 37:
        
         ctx.clearRect(p.x, p.y-1, p.height, p.width+2);    
        p.moveLeft();
        break;
    case 39:
         ctx.clearRect(p.x, p.y-1, p.height, p.width+2);    
        p.moveRight();
        break;
    case 38:
         ctx.clearRect(p.x, p.y+1, p.height, p.width);    
         p.moveUp();
        break;
    case 40:
         ctx.clearRect(p.x, p.y-1, p.height, p.width);    
        p.moveDown();
        break;
        case 32:
          b=new Bullet(p);
            
             b=new Bullet(p);
            t=setInterval("b.move()", 10);
            
          
    default:
        break;
    }
};


